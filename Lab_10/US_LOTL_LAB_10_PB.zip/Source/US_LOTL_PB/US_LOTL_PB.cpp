// Copyright Epic Games, Inc. All Rights Reserved.

#include "US_LOTL_PB.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, US_LOTL_PB, "US_LOTL_PB" );
